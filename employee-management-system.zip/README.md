# Employee Management System (EMS)

Full-stack hiring assignment implementation.

## Stack

- React + TypeScript + Vite
- Node.js + Express
- MongoDB + Mongoose
- JWT authentication
- bcrypt password hashing
- Responsive CSS UI

## Features

- Login/logout
- Protected routes
- JWT authentication
- Password hashing
- RBAC: Super Admin, HR Manager, Employee
- Employee CRUD
- Soft delete
- Search/filter/sort
- Pagination-ready employee API
- Dashboard metrics
- Reporting hierarchy
- Reporting manager assignment API
- Circular reporting prevention
- Employee self-profile editing

## Local setup

### Backend

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with MongoDB connection details
npm run seed
npm start
```

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
# Set VITE_API_URL if backend is deployed
npm run dev
```

## Demo credentials

- Super Admin: admin@ems.com / Password123
- HR Manager: hr@ems.com / Password123
- Employee: employee@ems.com / Password123

## API endpoints

### Authentication

- POST /api/auth/login
- POST /api/auth/logout

### Employees

- GET /api/employees
- POST /api/employees
- GET /api/employees/:id
- PUT /api/employees/:id
- DELETE /api/employees/:id
- GET /api/employees/:id/reportees
- PATCH /api/employees/:id/manager

### Dashboard

- GET /api/dashboard

### Organization

- GET /api/organization/tree

## Security notes

- Never commit `.env`.
- Change JWT_SECRET before deployment.
- Change seeded demo passwords for a real deployment.
