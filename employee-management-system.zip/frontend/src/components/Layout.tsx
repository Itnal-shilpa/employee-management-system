import { Link, useNavigate } from "react-router-dom";

export default function Layout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <div className="app">
      <header className="navbar">
        <div className="brand">EMS</div>
        <nav>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/employees">Employees</Link>
          <Link to="/organization">Organization</Link>
          <Link to="/profile">Profile</Link>
          <span className="role-pill">{user.role || ""}</span>
          <button onClick={logout}>Logout</button>
        </nav>
      </header>
      {children}
    </div>
  );
}
