import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import api from "../services/api";

interface DashboardData {
  totalEmployees: number;
  activeEmployees: number;
  inactiveEmployees: number;
  departmentCount: number;
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  useEffect(() => {
    api.get("/dashboard").then((res) => setData(res.data)).catch(console.error);
  }, []);

  return (
    <Layout>
      <main className="content">
        <div className="hero">
          <div>
            <p className="eyebrow">OVERVIEW</p>
            <h1>Welcome back, {user.name}</h1>
            <p className="muted">Monitor your workforce and organization at a glance.</p>
          </div>
        </div>

        <div className="stats">
          <div className="stat-card"><span>Total Employees</span><strong>{data?.totalEmployees ?? 0}</strong></div>
          <div className="stat-card"><span>Active Employees</span><strong>{data?.activeEmployees ?? 0}</strong></div>
          <div className="stat-card"><span>Inactive Employees</span><strong>{data?.inactiveEmployees ?? 0}</strong></div>
          <div className="stat-card"><span>Departments</span><strong>{data?.departmentCount ?? 0}</strong></div>
        </div>

        <div className="card">
          <h2>Employee Management System</h2>
          <p className="muted">
            Use Employees to manage staff records and Organization to view reporting relationships.
          </p>
        </div>
      </main>
    </Layout>
  );
}
