import { FormEvent, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../services/api";

type FormState = {
  employeeId: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  department: string;
  designation: string;
  salary: string;
  joiningDate: string;
  status: string;
  role: string;
};

const initial: FormState = {
  employeeId: "", name: "", email: "", password: "Password123", phone: "",
  department: "", designation: "", salary: "", joiningDate: "",
  status: "Active", role: "EMPLOYEE"
};

export default function EmployeeForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState<FormState>(initial);
  const [message, setMessage] = useState("");
  const isEdit = Boolean(id);
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  useEffect(() => {
    if (!id) return;
    api.get(`/employees/${id}`).then(({ data }) => {
      setForm({
        employeeId: data.employeeId || "",
        name: data.name || "",
        email: data.email || "",
        password: "",
        phone: data.phone || "",
        department: data.department || "",
        designation: data.designation || "",
        salary: data.salary?.toString() || "",
        joiningDate: data.joiningDate ? data.joiningDate.slice(0, 10) : "",
        status: data.status || "Active",
        role: data.role || "EMPLOYEE"
      });
    }).catch((error) => setMessage(error.response?.data?.message || "Could not load employee"));
  }, [id]);

  const update = (key: keyof FormState, value: string) => setForm((old) => ({ ...old, [key]: value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setMessage("");

    try {
      if (isEdit) {
        await api.put(`/employees/${id}`, {
          ...form,
          salary: Number(form.salary)
        });
      } else {
        await api.post("/employees", {
          ...form,
          salary: Number(form.salary)
        });
      }
      navigate("/employees");
    } catch (error: any) {
      setMessage(error.response?.data?.message || "Something went wrong");
    }
  };

  const canAssignSuperAdmin = user.role === "SUPER_ADMIN";

  return (
    <Layout>
      <main className="content narrow">
        <div className="card">
          <p className="eyebrow">EMPLOYEE</p>
          <h1>{isEdit ? "Edit Employee" : "Add Employee"}</h1>
          {message && <div className="error">{message}</div>}

          <form onSubmit={submit} className="form-grid">
            <label>Employee ID<input value={form.employeeId} disabled={isEdit} onChange={(e) => update("employeeId", e.target.value)} required /></label>
            <label>Name<input value={form.name} onChange={(e) => update("name", e.target.value)} required /></label>
            <label>Email<input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} required /></label>
            {!isEdit && <label>Password<input type="password" value={form.password} onChange={(e) => update("password", e.target.value)} required /></label>}
            <label>Phone<input value={form.phone} onChange={(e) => update("phone", e.target.value)} /></label>
            <label>Department<input value={form.department} onChange={(e) => update("department", e.target.value)} required /></label>
            <label>Designation<input value={form.designation} onChange={(e) => update("designation", e.target.value)} required /></label>
            <label>Salary<input type="number" min="0" value={form.salary} onChange={(e) => update("salary", e.target.value)} /></label>
            <label>Joining Date<input type="date" value={form.joiningDate} onChange={(e) => update("joiningDate", e.target.value)} /></label>
            <label>Status<select value={form.status} onChange={(e) => update("status", e.target.value)}><option>Active</option><option>Inactive</option></select></label>
            <label>Role<select value={form.role} onChange={(e) => update("role", e.target.value)}>
              <option value="EMPLOYEE">Employee</option>
              <option value="HR_MANAGER">HR Manager</option>
              {canAssignSuperAdmin && <option value="SUPER_ADMIN">Super Admin</option>}
            </select></label>

            <div className="form-actions">
              <button type="button" onClick={() => navigate("/employees")}>Cancel</button>
              <button className="primary" type="submit">{isEdit ? "Update Employee" : "Create Employee"}</button>
            </div>
          </form>
        </div>
      </main>
    </Layout>
  );
}
