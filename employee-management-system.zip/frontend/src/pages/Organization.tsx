import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import api from "../services/api";

interface Employee {
  _id: string;
  name: string;
  employeeId: string;
  designation: string;
  role: string;
  children: Employee[];
}

function TreeNode({ employee }: { employee: Employee }) {
  return (
    <div className="tree-node">
      <div className="employee-node">
        <strong>{employee.name}</strong>
        <span>{employee.designation}</span>
        <small>{employee.employeeId} · {employee.role}</small>
      </div>
      {employee.children?.length > 0 && (
        <div className="children">
          {employee.children.map((child) => <TreeNode key={child._id} employee={child} />)}
        </div>
      )}
    </div>
  );
}

export default function Organization() {
  const [tree, setTree] = useState<Employee[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/organization/tree")
      .then(({ data }) => setTree(data))
      .catch((e) => setError(e.response?.data?.message || "Could not load organization"));
  }, []);

  return (
    <Layout>
      <main className="content">
        <p className="eyebrow">STRUCTURE</p>
        <h1>Organization Hierarchy</h1>
        {error && <div className="error">{error}</div>}
        <div className="card organization">
          {tree.length ? tree.map((employee) => <TreeNode key={employee._id} employee={employee} />) : <p className="muted">No employees found.</p>}
        </div>
      </main>
    </Layout>
  );
}
