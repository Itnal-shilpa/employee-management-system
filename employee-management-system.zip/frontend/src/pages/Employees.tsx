import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import api from "../services/api";

interface Employee {
  _id: string;
  employeeId: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  salary: number;
  status: string;
  role: string;
  joiningDate?: string;
  reportingManager?: { name: string };
}

export default function Employees() {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState("name");
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const loadEmployees = async () => {
    try {
      setLoading(true);
      const { data } = await api.get("/employees", {
        params: { search, department, role, status, sort, limit: 50 }
      });
      setEmployees(data.employees);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(loadEmployees, 250);
    return () => clearTimeout(timer);
  }, [search, department, role, status, sort]);

  const deleteEmployee = async (id: string) => {
    if (!window.confirm("Delete this employee?")) return;
    try {
      await api.delete(`/employees/${id}`);
      loadEmployees();
    } catch (error: any) {
      alert(error.response?.data?.message || "Delete failed");
    }
  };

  return (
    <Layout>
      <main className="content">
        <div className="page-header">
          <div>
            <p className="eyebrow">PEOPLE</p>
            <h1>Employees</h1>
          </div>
          {(user.role === "SUPER_ADMIN" || user.role === "HR_MANAGER") && (
            <button className="primary" onClick={() => navigate("/employees/new")}>+ Add Employee</button>
          )}
        </div>

        <div className="filters">
          <input placeholder="Search name or email..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <input placeholder="Department" value={department} onChange={(e) => setDepartment(e.target.value)} />
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="">All roles</option>
            <option value="SUPER_ADMIN">Super Admin</option>
            <option value="HR_MANAGER">HR Manager</option>
            <option value="EMPLOYEE">Employee</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="name">Sort: Name</option>
            <option value="joiningDate">Sort: Joining Date</option>
          </select>
        </div>

        <div className="card table-wrap">
          {loading ? <p>Loading employees...</p> : (
            <table>
              <thead>
                <tr>
                  <th>ID</th><th>Name</th><th>Email</th><th>Department</th>
                  <th>Designation</th><th>Role</th><th>Status</th><th>Manager</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((employee) => (
                  <tr key={employee._id}>
                    <td>{employee.employeeId}</td>
                    <td><strong>{employee.name}</strong></td>
                    <td>{employee.email}</td>
                    <td>{employee.department}</td>
                    <td>{employee.designation}</td>
                    <td><span className="badge">{employee.role}</span></td>
                    <td><span className={employee.status === "Active" ? "status active" : "status inactive"}>{employee.status}</span></td>
                    <td>{employee.reportingManager?.name || "—"}</td>
                    <td className="actions">
                      <button onClick={() => navigate(`/employees/${employee._id}/edit`)}>Edit</button>
                      {user.role === "SUPER_ADMIN" && (
                        <button className="danger" onClick={() => deleteEmployee(employee._id)}>Delete</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </Layout>
  );
}
