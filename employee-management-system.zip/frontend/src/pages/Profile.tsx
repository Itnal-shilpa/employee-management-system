import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import api from "../services/api";

export default function Profile() {
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const [profile, setProfile] = useState<any>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    api.get(`/employees/${user.id}`).then(({ data }) => {
      setProfile(data);
      setName(data.name || "");
      setPhone(data.phone || "");
    }).catch((error) => setMessage(error.response?.data?.message || "Could not load profile"));
  }, [user.id]);

  const save = async () => {
    try {
      const { data } = await api.put(`/employees/${user.id}`, { name, phone });
      setProfile(data);
      setMessage("Profile updated successfully.");
      localStorage.setItem("user", JSON.stringify({ ...user, name: data.name }));
    } catch (error: any) {
      setMessage(error.response?.data?.message || "Update failed");
    }
  };

  return (
    <Layout>
      <main className="content narrow">
        <div className="card">
          <p className="eyebrow">ACCOUNT</p>
          <h1>My Profile</h1>
          {message && <div className="success">{message}</div>}
          {profile && (
            <div className="form-grid">
              <label>Employee ID<input value={profile.employeeId} disabled /></label>
              <label>Name<input value={name} onChange={(e) => setName(e.target.value)} /></label>
              <label>Email<input value={profile.email} disabled /></label>
              <label>Phone<input value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
              <label>Department<input value={profile.department} disabled /></label>
              <label>Designation<input value={profile.designation} disabled /></label>
              <label>Role<input value={profile.role} disabled /></label>
              <button className="primary" onClick={save}>Save Changes</button>
            </div>
          )}
        </div>
      </main>
    </Layout>
  );
}
